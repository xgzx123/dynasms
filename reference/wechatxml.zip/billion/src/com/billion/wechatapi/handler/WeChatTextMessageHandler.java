package com.billion.wechatapi.handler;

import com.billion.beans.wechat.WeChatMessageBean;
import com.billion.beans.wechat.WeChatTextMessageBean;

public class WeChatTextMessageHandler extends WeChatMessageContentHandler {
	public final static String CONTENT_START = "<Content><![CDATA[";
	public final static String CONTENT_END = "]]></Content>";

	@Override
	public int recordDownWeChatMessage(WeChatMessageBean message) {
		
		return 0;
	}

	@Override
	public String processMessageContent(WeChatMessageBean message) {
		WeChatTextMessageBean text = (WeChatTextMessageBean) message;
		StringBuilder sb = new StringBuilder();
		sb.append(CONTENT_START);
		sb.append(text);
		sb.append(CONTENT_END);
		// 位0x0001被标志时，星标刚收到的消息
		sb.append(FUNC_START);
		sb.append(0);
		sb.append(FUNC_END);
		return sb.toString();
	}

}
