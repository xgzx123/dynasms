/**
 * 
 */
package com.billion.wechatapi.handler;

import com.billion.beans.wechat.WeChatMessageBean;

/**
 * @author stlv
 * 
 */
public abstract class WeChatMessageContentHandler {
	public final static String XML_START = "<xml>";
	public final static String XML_END = "</xml>";
	public final static String TOUN_START = "<ToUserName><![CDATA[";
	public final static String TOUN_END = "]]></ToUserName>";
	public final static String FROMUN_START = "<FromUserName><![CDATA[";
	public final static String FROMUN_END = "]]></FromUserName>";
	public final static String CRTTIME_START = "<CreateTime>";
	public final static String CRTTIME_END = "</CreateTime>";
	public final static String FUNC_START = "<FuncFlag>";
	public final static String FUNC_END = "</FuncFlag>";
	public final static String MSGTYPE_START = "<MsgType><![CDATA[";
	public final static String MSGTYPE_END = "]]></MsgType>";

	public String processMessage(WeChatMessageBean message) {
		recordDownWeChatMessage(message);
		return processReplyXML(message);
	}

	/**
	 * // fetch user registered reply message
	 */
	public abstract String processMessageContent(WeChatMessageBean message);

	/**
	 * record the message into DB
	 * 
	 * @param message
	 * @return
	 */
	public abstract int recordDownWeChatMessage(WeChatMessageBean message);

	/**
	 * reply message in XML format
	 * 
	 * @param message
	 * @return
	 */
	private String processReplyXML(WeChatMessageBean message) {
		StringBuilder replyXML = new StringBuilder(XML_START);
		replyXML.append(TOUN_START);
		replyXML.append(message.getFromUserName());
		replyXML.append(TOUN_END);
		replyXML.append(FROMUN_START);
		replyXML.append(message.getToUserName());
		replyXML.append(FROMUN_END);
		replyXML.append(CRTTIME_START);
		replyXML.append(System.currentTimeMillis());
		replyXML.append(CRTTIME_END);
		replyXML.append(processMessageContent(message));
		replyXML.append(XML_END);
		return replyXML.toString();
	}

}
