package com.billion.wechatapi.handler;

import com.billion.beans.wechat.WeChatMessageBean;

public class WeChatLinkMessageHandler extends WeChatMessageContentHandler {
	@Override
	public int recordDownWeChatMessage(WeChatMessageBean message) {
		return 0;
	}

	@Override
	public String processMessageContent(WeChatMessageBean message) {
		return null;
	}

}
