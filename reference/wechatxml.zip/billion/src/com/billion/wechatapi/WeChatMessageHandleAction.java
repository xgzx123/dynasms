package com.billion.wechatapi;

import java.io.PrintWriter;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.ibatis.session.SqlSession;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.interceptor.ServletResponseAware;
import org.jdom2.Document;
import org.jdom2.input.SAXBuilder;

import com.billion.beans.wechat.WeChatMessageBean;
import com.billion.dao.WeixinAccountMapper;
import com.billion.dbutil.SQLSessionFactory;
import com.billion.model.WeixinAccount;
import com.billion.model.WeixinAccountExample;
import com.billion.wechatapi.handler.WeChatMessageContentHandler;
import com.opensymphony.xwork2.ActionSupport;

public class WeChatMessageHandleAction extends ActionSupport implements
		ServletResponseAware {
	private Integer wcAccUid = -1;
	private static final long serialVersionUID = 1L;

	private javax.servlet.http.HttpServletResponse response;

	public String execute() {
		HttpServletRequest request = ServletActionContext.getRequest();
		try {
			// check if user registered by UID
			WeixinAccount wxAcct = getWeChatUserAccountByUID();
			if (null == wxAcct)
				return null;

			// fetch XML from request stream
			SAXBuilder builder = new SAXBuilder();
			Document doc = builder.build(request.getInputStream());

			// convert xml to java bean
			MessageHandlingContext context = new MessageHandlingContext(doc);

			WeChatMessageBean message = context.getMessage();
			WeChatMessageContentHandler hdlder = context.getHandler();
			String replyContent = hdlder.processMessage(message);

			response.setContentType("text/xml;charset=utf-8");
			response.setCharacterEncoding("UTF-8");
			PrintWriter writer = response.getWriter();
			writer.write(replyContent);
			writer.flush();
			writer.close();
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		}
		return null;
	}

	private WeixinAccount getWeChatUserAccountByUID() throws Exception {
		WeixinAccount wcAcct = null;
		SqlSession sqlSession = new SQLSessionFactory().getSession();
		WeixinAccountMapper accountMapper = sqlSession
				.getMapper(WeixinAccountMapper.class);
		WeixinAccountExample accountExample = new WeixinAccountExample();
		accountExample.createCriteria().andUidEqualTo(wcAccUid);
		List<WeixinAccount> wcAcctList = accountMapper
				.selectByExample(accountExample);
		sqlSession.close();
		if (null != wcAcctList && !wcAcctList.isEmpty()) {
			if (wcAcctList.size() != 1)
				throw new Exception("wcAccUid = " + wcAccUid + " 对应于多个帐号!");
			wcAcct = wcAcctList.get(0);
		} else {
			wcAcct = null;
			throw new Exception("微信帐号未在系统中注册!");
		}
		return wcAcct;
	}

	public Integer getWcAccUid() {
		return wcAccUid;
	}

	public void setWcAccUid(Integer wcAccUid) {
		this.wcAccUid = wcAccUid;
	}

	public void setServletResponse(HttpServletResponse arg0) {
		this.response = arg0;
	}

}