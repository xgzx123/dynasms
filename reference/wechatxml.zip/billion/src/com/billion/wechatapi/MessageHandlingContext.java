/**
 * 
 */
package com.billion.wechatapi;

import java.util.List;

import org.jdom2.Content;
import org.jdom2.Document;
import org.jdom2.Element;

import com.billion.beans.wechat.WeChatEventEnterMessageBean;
import com.billion.beans.wechat.WeChatEventLocationMessageBean;
import com.billion.beans.wechat.WeChatLinkMessageBean;
import com.billion.beans.wechat.WeChatLocationMessageBean;
import com.billion.beans.wechat.WeChatMessageBean;
import com.billion.beans.wechat.WeChatMessageTypeConstants;
import com.billion.beans.wechat.WeChatPictureMessageBean;
import com.billion.beans.wechat.WeChatTextMessageBean;
import com.billion.wechatapi.handler.WeChatEventEnterMessageHandler;
import com.billion.wechatapi.handler.WeChatEventLocationMessageHandler;
import com.billion.wechatapi.handler.WeChatImageMessageHandler;
import com.billion.wechatapi.handler.WeChatLinkMessageHandler;
import com.billion.wechatapi.handler.WeChatMessageContentHandler;
import com.billion.wechatapi.handler.WeChatTextMessageHandler;

/**
 * @author stlv
 * 
 */
public class MessageHandlingContext {
	private Element root;
	private WeChatMessageContentHandler handler;
	private WeChatMessageBean message;

	public MessageHandlingContext(Document doc) {
		this.root = doc.getRootElement();
		convertDocumentToMessageBean();
	}

	public WeChatMessageBean convertDocumentToMessageBean() {
		String msgType = getFirstCDATAValueFromElement(root.getChild("MsgType"));
		if (msgType.equalsIgnoreCase(WeChatMessageTypeConstants.TEXT)) {
			message = new WeChatTextMessageBean();
			handler = new WeChatTextMessageHandler();
		} else if (msgType.equalsIgnoreCase(WeChatMessageTypeConstants.IMAGE)) {
			message = new WeChatPictureMessageBean();
			handler = new WeChatImageMessageHandler();
		} else if (msgType.equalsIgnoreCase(WeChatMessageTypeConstants.LINK)) {
			message = new WeChatLinkMessageBean();
			handler = new WeChatLinkMessageHandler();
		} else if (msgType
				.equalsIgnoreCase(WeChatMessageTypeConstants.LOCATION)) {
			message = new WeChatLocationMessageBean();
			handler = new WeChatEventLocationMessageHandler();
		} else if (msgType.equalsIgnoreCase(WeChatMessageTypeConstants.EVENT)) {
			String event = getFirstCDATAValueFromElement(root.getChild("Event"));
			if (event.equalsIgnoreCase(WeChatMessageTypeConstants.EVENT_ENTER)) {
				message = new WeChatEventEnterMessageBean();
				handler = new WeChatEventEnterMessageHandler();
			} else if (event
					.equalsIgnoreCase(WeChatMessageTypeConstants.EVENT_LOCATION)) {
				message = new WeChatEventLocationMessageBean();
				handler = new WeChatEventLocationMessageHandler();
			}
		} else {
			// default handle it as text
			message = new WeChatTextMessageBean();
			handler = new WeChatTextMessageHandler();
		}
		return fillWeChatMessageBeanValues(message, root);
	}

	private WeChatMessageBean fillWeChatMessageBeanValues(WeChatMessageBean wb,
			Element root) {
		wb.setCreateTime(Long.valueOf(root.getChildText("CreateTime")));
		wb.setFromUserName(getFirstCDATAValueFromElement(root
				.getChild("FromUserName")));
		wb.setToUserName(getFirstCDATAValueFromElement(root
				.getChild("ToUserName")));
		if (null != root.getChildText("MsgId"))
			wb.setMsgId(Long.valueOf((root.getChildText("MsgId"))));
		if (wb instanceof WeChatTextMessageBean) {
			WeChatTextMessageBean t = (WeChatTextMessageBean) wb;
			t.setContent(getFirstCDATAValueFromElement(root.getChild("Content")));
		} else if (wb instanceof WeChatPictureMessageBean) {
			WeChatPictureMessageBean p = (WeChatPictureMessageBean) wb;
			p.setPicUrl(getFirstCDATAValueFromElement(root.getChild("PicUrl")));
		} else if (wb instanceof WeChatLinkMessageBean) {
			WeChatLinkMessageBean l = (WeChatLinkMessageBean) wb;
			l.setDescription(getFirstCDATAValueFromElement(root
					.getChild("Description")));
			l.setTitle(getFirstCDATAValueFromElement(root.getChild("Title")));
			l.setUrl(getFirstCDATAValueFromElement(root.getChild("Url")));
		} else if (wb instanceof WeChatLocationMessageBean) {
			WeChatLocationMessageBean loc = (WeChatLocationMessageBean) wb;
			loc.setLabel(getFirstCDATAValueFromElement(root.getChild("Label")));
			loc.setLocationX(Double.valueOf(root.getChildText("Location_X")));
			loc.setLocationY(Double.valueOf(root.getChildText("Location_Y")));
			loc.setScale(Integer.valueOf(root.getChildText("Location_Y")));
		} else if (wb instanceof WeChatEventEnterMessageBean) {
			// TODO currently do nothing
		} else if (wb instanceof WeChatEventLocationMessageBean) {
			WeChatEventLocationMessageBean el = (WeChatEventLocationMessageBean) wb;
			el.setLatitude(Double.valueOf(root.getChildText("Latitude")));
			el.setLongitude(Double.valueOf(root.getChildText("Longitude")));
			el.setPrecision(Double.valueOf(root.getChildText("Precision")));
		}
		return wb;
	}

	private String getFirstCDATAValueFromElement(Element ele) {
		String value = null;
		List<Content> contentList = ele.getContent();
		for (Content ctnt : contentList) {
			if (ctnt.getCType().equals(Content.CType.CDATA)) {
				value = ctnt.getValue();
				break;
			}
		}
		return value;
	}

	public WeChatMessageContentHandler getHandler() {
		return handler;
	}

	public void setHandler(WeChatMessageContentHandler handler) {
		this.handler = handler;
	}

	public WeChatMessageBean getMessage() {
		return message;
	}

	public void setMessage(WeChatMessageBean message) {
		this.message = message;
	}

	public Element getRoot() {
		return root;
	}

	public void setRoot(Element root) {
		this.root = root;
	}

}
